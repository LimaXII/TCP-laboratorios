package poligonos;

interface Poligono {
    public final int tamanhoDoCanvas = 100;
    public float calculaArea();
    public void imprimeTipoPoligono();    
}