package poligonos;

// Interface polígono.
interface Poligono {
    // Tamanho do canvas.
    public final int tamanhoDoCanvas = 100;
    public float calculaArea();
    public void imprimeTipoPoligono();    
}